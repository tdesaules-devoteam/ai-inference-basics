# kserve-llmisvc-crd-minimal

Helm chart for deploying LLMInferenceService minimal crds

![Version: v0.21.0](https://img.shields.io/badge/Version-v0.21.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v0.21.0](https://img.shields.io/badge/AppVersion-v0.21.0-informational?style=flat-square)

## Installing the Chart

To install the chart, run the following:

```console
$ helm install kserve-llmisvc-crd-minimal oci://ghcr.io/kserve/charts/kserve-llmisvc-crd-minimal --version v0.21.0
```
